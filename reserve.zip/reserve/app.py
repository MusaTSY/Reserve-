from flask import Flask , render_template, request,redirect,url_for,Response
from flask_sqlalchemy import SQLAlchemy 
from datetime import datetime 
import time



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app) 

class make_reservation_bp(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    Reservation_name = db.Column(db.String(100), nullable = False, default = "N/A")
    Reservation_info = db.Column(db.String(100), nullable = False) 
    Reservation_num =  db.Column(db.Integer)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)



    def __repr__(self):
        return'<Reservation %r>' %self.id 


@app.route('/', methods = ['POST', 'GET'])
def index():       
    if request.method == 'POST':

        r_sit = request.form['sit']
        r_info = request.form['content']
        r_name = request.form['title']
        r_info_model= make_reservation_bp(Reservation_info = r_info, Reservation_name = r_name, Reservation_num = int(r_sit or 0))
        db.session.add(r_info_model)
        db.session.commit()
        
        return redirect('/')

    else:
        r_add = make_reservation_bp.query.all()
        return render_template('index.html', Reservations = r_add)



@app.route('/delete/<int:id>')
def delete(id):
    r_delete = make_reservation_bp.query.get_or_404(id)
    db.session.delete(r_delete)
    db.session.commit()
    return redirect('/') 

@app.route('/timeactive/<int:id>')
def delete2(id):
    Reservation_timer(10)#i would make 3600 secs for an hour for test it's 10 
    r_delete = make_reservation_bp.query.get_or_404(id)
    db.session.delete(r_delete)
    db.session.commit()

    return redirect('/') 
    

def Reservation_timer(t):
    
    while t:
        mins, secs = divmod(t, 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        print(timer, end="\r")#shows in the output log 
        time.sleep(1)
        t -= 1

    return redirect('/') 



if __name__ == "__main__":
    app.run()
    app.run(debug = True)
